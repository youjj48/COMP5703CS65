# SpiderKeeper Changelog
## 1.2.0 (2017-07-24)
- support chose server manually
- support set cron exp manually
- fix log Chinese decode problem
- fix scheduler trigger not fire problem
- fix not delete project on scrapyd problem

## 1.1.0 (2017-04-25)
- support basic auth
- show spider crawl time info (last_runtime,avg_runtime)
- optimized for mobile

## 1.0.3 (2017-04-17)
- support view log

## 1.0.0 (2017-03-30)
- refactor
- support py3
- optimized api
- optimized scheduler
- more scalable (can support access multiply spider service)
- show running stats

## 0.2.0 (2016-04-13)
- support view job of multi daemons.
- support run on multi daemons.
- support choice running daemon automaticaly.

## 0.1.1 (2016-02-16)
- add status monitor(https://github.com/afaqurk/linux-dash)

## 0.1.0 (2016-01-18)
- initial.