/**
 * Created by modm on 2017/4/7.
 */
$(document).ready()
$.get("/api/projects",function (data){

})